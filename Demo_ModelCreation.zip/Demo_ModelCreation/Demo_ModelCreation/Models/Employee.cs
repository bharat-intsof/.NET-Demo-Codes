﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo_ModelCreation.Models
{
    public class Employee
    {
    }
}
