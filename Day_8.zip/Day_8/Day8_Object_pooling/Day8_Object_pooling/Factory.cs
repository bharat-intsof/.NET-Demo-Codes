﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8_Object_pooling
{
    internal class Factory
    {
        private static int PoolMaxSize = 2;
        private static readonly Queue ObjPool = new Queue(PoolMaxSize);
        public Employee GetEmployee()
        {
            GetEmployee OEmployee = new GetEmployee();
            if (Employee.Counter >= PoolMaxSize && ObjPool.Count > 0 )
            {
                OEmployee = RetriveFormPool();
            }
            else
            {
                OEmployee = GetNewEmployee();
            }
            return OEmployee;
        }
        protected Employee RetriveFromPool()
        {
            Employee OEmp;
            //If there is nay object in my collection
            if(ObjPool.Count > 0)
            {
                OEmp = (Employee)ObjPool.Dequeue();
                GetEmployee().Count--;
            }
            else
            {
                //returning a new object
                OEmp = new Employee();
            }
            return (OEmp);
        }
        private Employee GetNewEmployee()
        {
            //Creating a new Employee
            Employee OEmp = new Employee();
            ObjPool.Enqueue(OEmp);
            return OEmp;
            Console.WriteLine("New Object is created");
        }
    }
}
