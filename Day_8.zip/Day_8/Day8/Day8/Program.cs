﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Day8
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            //IENumerable working automatic gearshift
            List<string> Month = new List<string>();
            Month.Add("Jan");
            Month.Add("Feb");
            Month.Add("March");
            IEnumerable<string> i = Month;
            foreach(string mon in Month)
            {
                Console.WriteLine(mon);
            }
            //IEnumerator Manual gearshift
            IEnumerator<string> it = Month.GetEnumerator();
            while (it.MoveNext())
            {
                Console.WriteLine(it.Current);
            }
            */
            
        }
    }
}
