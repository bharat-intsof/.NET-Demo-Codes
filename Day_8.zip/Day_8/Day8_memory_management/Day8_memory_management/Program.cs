﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8_memory_management
{
    class Program
    {
        public static void Free()
        {

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Destructors in c#");

            Complex C = new Complex();
            C.SetValue(4, 7);
            C.DisplayValue();
            Console.WriteLine("End of Code....");
        }
    }
}
