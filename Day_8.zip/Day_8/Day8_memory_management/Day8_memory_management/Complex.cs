﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8_memory_management
{
    //IDisposable interface contains Dispose() for realeasing unmanagable resources files, connection string,strems
    class Complex : IDisposable
    {
        int real, imaginary;

        public Complex()
        {
            real = 0;
            imaginary = 0;
        }

        public void SetValue(int r, int i)
        {
            real = r;
            imaginary = i;
        }

        public void DisplayValue()
        {
            Console.WriteLine("real ="+real);
            Console.WriteLine("imahinary ="+imaginary);
        }

        public void Dispose()
        {
            Console.WriteLine("Dispose() is called to dispose resources");
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
                Console.WriteLine("Cleaning up all managed resources - along with child object indisposable interface");
        }

        ~Complex()
        {
            Console.WriteLine("Destructor is called...!!!");
            //c# compiler will convert destructor method in finalize method 
            Dispose(false);
        }
    }
}
