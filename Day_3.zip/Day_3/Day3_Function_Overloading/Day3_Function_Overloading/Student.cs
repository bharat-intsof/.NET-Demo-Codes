﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_FunctionOverloading
{
    internal class Student
    {
        public void StudentMesssage()
        {
            Console.WriteLine(" I am A Message coming from student class....!!!!");
        }
    }
}