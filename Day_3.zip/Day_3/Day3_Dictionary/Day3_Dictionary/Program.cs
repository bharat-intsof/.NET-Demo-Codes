﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dictinoray Implementation");

            Dictionary<string, string> EmpList = new Dictionary<string, string>();
            EmpList.Add("Aman", "Programmer");
            EmpList.Add("Avinash", "Architect");
            EmpList.Add("Kartik", "Manager");

            foreach(KeyValuePair<string,string> item in EmpList)
            {
                Console.WriteLine($"Name:{item.Key} and Dict:{item.Value}");
            }
        }
    }
}
