﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_Hash_Table_NonGeneric
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hash Table Implementation - Non Generic Collection Class");

        }
    }
}
