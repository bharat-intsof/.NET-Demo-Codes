﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Constructor
{
    internal class Employee
    {
        public string name;
        public string dept;
        public Employee() // default constructor
        {
            dept = "Training & Development";
        }
        public Employee(string name, string dept)// Parametrised constructor
        {
            this.name = name;
            this.dept = dept;
        }
    }

}
