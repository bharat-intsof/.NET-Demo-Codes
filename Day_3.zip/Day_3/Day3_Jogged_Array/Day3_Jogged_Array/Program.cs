﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_Jogged_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] nyarr = new int[3][];
            nyarr[0] = new int[4] { 11, 21, 31, 41 };
            nyarr[1] = new int[6] { 12,22,32,42,52,62 };
            nyarr[2] = new int[] { 13,12,24,46,68,79,87,23,56 };


        }
    }
}
