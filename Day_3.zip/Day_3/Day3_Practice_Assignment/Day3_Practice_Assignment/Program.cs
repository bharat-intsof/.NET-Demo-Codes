﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_Practice_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Practic Assignment");

            Dictionary<string, Int16> AuthorList = new Dictionary<string, Int16>();
            Dictionary<string, float> PriceList = new Dictionary<string, float>();

            AuthorList.Add("Pablo", 1);
            AuthorList.Add("McClane", 2);
            AuthorList.Add("Wick", 3);
            PriceList.Add("Pablo", 20.8F);
            PriceList.Add("McClane", 19.8F);
            PriceList.Add("Wick", 15.8F);

            AuthorList.Remove("Pablo");
            foreach(KeyValuePair<string,Int16> item in AuthorList)
            {
                Console.WriteLine($"Name:{item.Key} and Dict:{item.Value}");
            }

            if (AuthorList.ContainsKey("Pablo"))
            {
                Console.WriteLine("Item Match");
            }

            if(AuthorList.ContainsValue(3))
            {
                Console.WriteLine("Item Match");
            }

            Console.WriteLine("Count: {0}", AuthorList.Count);
        }
    }
}
