﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Demo_ADO.NET_with_Data_Grid
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //creating a Connection Object
            string ConnectionString = "Data Source=192.168.1.230;Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022";
            SqlConnection myConnection = new SqlConnection();
            myConnection.ConnectionString = ConnectionString;

            myConnection.Open();

            //creating a SQL string Data adopter object
            string queryString = "select * from BH_Employee";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(queryString, myConnection.ConnectionString);
           
            //myConnection.Close();

            //Creating dataset and filling it 
            DataSet dataset = new DataSet("BH_Employee");
            sqlDataAdapter.Fill(dataset);

            //Binding the DataGrid control to Dataset
            dataGridView1.DataSource = dataset.Tables[0];

            //myConnection.Dispose();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'freshers_Training2022DataSet.BH_Employee' table. You can move, or remove it, as needed.
            this.bH_EmployeeTableAdapter.Fill(this.freshers_Training2022DataSet.BH_Employee);

        }
    }
}
