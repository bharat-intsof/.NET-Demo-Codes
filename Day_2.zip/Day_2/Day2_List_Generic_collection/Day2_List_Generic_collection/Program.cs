﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_List_Generic_collection
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Impliminting Generic List Collection");
            var movies = new List<String>();
            movies.Add("John Wick");

            Console.WriteLine(movies.Capacity);
            Console.WriteLine(movies.Count);
        }

    }
}
