﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Day2_Timer_using__Thread
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Using thread for displaying Time in a loop");
            for (int i = 0; i < 200; i++)
            {
                Console.WriteLine(DateTime.Now);
                Thread.Sleep(1000);
            }
            Console.WriteLine("Finally the time is: ");
            Console.WriteLine(DateTime.Now);
        }
    }
}
