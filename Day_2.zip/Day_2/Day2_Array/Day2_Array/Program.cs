﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("*******Display with FOR LOOP********");
            int[] num = { 1, 2, 3, 4, 5 };
            for(int i=0;i<num.Length;i++)
            {
                Console.WriteLine(num[i]);
            }



            Console.WriteLine("***************Display with FOREACH************");
            foreach(var item in num)
            { 
                Console.WriteLine(item);
            }

            Console.WriteLine("************Sorting**************");
            Console.WriteLine(num.Sort())

            Console.WriteLine("********Display MIN***********");
            Console.WriteLine(num.Min());


            Console.WriteLine("********Display MAX***********");
            Console.WriteLine(num.Max());


            Console.WriteLine("********Display SUM***********");
            Console.WriteLine(num.Sum();
        }
    }
}
