﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_IF_ELSE_Conditions
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with IF Else Conditions!");
            Console.WriteLine("Enter your age: ");
            int age = Convert.ToInt32(Console.ReadLine());

            if (age >= 18)
            {
                Console.WriteLine("You are eligible for voting in India!!");
            }
            else
            {
                Console.WriteLine("Watch Cartoon and Play inside Homw...!!");
            }
        }
    }
}
