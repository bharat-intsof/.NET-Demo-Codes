﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_Date_Time
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with Date Time");
            DateTime todaysdate = new DateTime(2022,09,01,10,38,45);
            Console.WriteLine(todaysdate.Year);
            Console.WsriteLine(todaysdate.Month);
            Console.WriteLine(todaysdate.Day);

            Console.WriteLine("-------------Displaying  Time ---------------");
            Console.WriteLine(todaysdate.Hour);
            Console.WriteLine(todaysdate.Minute);
            Console.WriteLine(todaysdate.Second);

            Console.WriteLine(todaysdate.DayOfWeek);
            Console.WriteLine(todaysdate.ToString("MMMM, dd , yyyy"));

            Console.WriteLine(DateTime.Now);
            Console.WriteLine(DateTime.MinValue);
            Console.WriteLine(DateTime.MaxValue);
        }
    }
}
