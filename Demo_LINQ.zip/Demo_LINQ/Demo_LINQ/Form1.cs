﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_LINQ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Defining a string Array
            string[] names = { "Wings of FIRE",
                               "Rich Dad Poor Dad",
                               "Deep Work",
                               "Think Rich ",
                               "Every One You Hate is going to die"};

            //LINQ query
            IEnumerable<string> AllTimeFavBooks = from name in names
                                                 where name.Length > 5
                                                 select name;

            //For each in display books 
            foreach (var name in AllTimeFavBooks)
            {
                richTextBox1.AppendText(name + "\n");
            }
        }
    }
}
