﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace Demo_LINQ_to_Object
{
    public partial class LINQ_to_SQL : Form
    {
        public LINQ_to_SQL()
        {
            InitializeComponent();
        }

        private void LINQ_to_SQL_Load(object sender, EventArgs e)
        {

        }
    }
}
