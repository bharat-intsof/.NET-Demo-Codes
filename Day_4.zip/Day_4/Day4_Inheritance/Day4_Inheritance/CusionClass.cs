﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4_Inheritance
{
    internal class CousinClass : BaseClass
    {
        public CousinClass()
        {
            Console.WriteLine("This message is coming from another child class inheriting same base class");
        }
    }
}
