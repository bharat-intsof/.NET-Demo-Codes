﻿using System;

namespace Day4_Static_Classes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // We Dont Need to Create Object
            //Static functions can be called from other functions directly
            Console.WriteLine("Static Classes in C# ");
            Console.WriteLine(MyCollege.CollegeName + "\n" + MyCollege.CollegeAddress + "\n" + MyCollege.CollegeCity);
            //MyCollege.EstablishmentYear = "1974";
            Console.WriteLine(MyCollege.EstablishmentYear + ": is the year of Establishment");
        }
    }
}
