﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day4_Static_Classes
{
    static class MyCollege
    {
        public static string CollegeName;
        public static string CollegeAddress;
        public static string CollegeCity;

        private static string yearofEstablishment = "2001";
        //private string streams;
        public static string EstablishmentYear
        {
            get { return yearofEstablishment; }
            set { yearofEstablishment = value; }
        }

        static MyCollege()
        {
            CollegeName = " College Of Enginering Pune";
            CollegeAddress = " Station Road Pune ";
            CollegeCity = " Pune - (M.H) - India ";
        }

    }
}