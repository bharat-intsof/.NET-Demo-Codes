﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Demo_MultiThreading
{
    public class MyThread
    {
        public static void ThreadDisplay()
        {
            for (int i=0; i < 3; i++)
            {
                Console.WriteLine("First Thread"+i);
            }
        }
        public static void Thread2Display()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Second Thread"+i);
            }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MultiThreading in Action");
            //MyThread obj1 = new MyThread();
            //Thread thread1 = new Thread(new ThreadStart(obj1.ThreadDisplay));
            //thread1.Start();

            Thread a = new Thread(MyThread.ThreadDisplay);
            Thread b = new Thread(MyThread.Thread2Display);
            a.Start();
            b.Start();
            Console.WriteLine("Both thread are running");
        }
    }
}
