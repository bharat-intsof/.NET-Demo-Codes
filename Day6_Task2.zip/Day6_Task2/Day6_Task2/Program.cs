﻿using System;

namespace Day6_Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Order");
            Order a = new Order();
            try
            {

                a.show();
            }
            catch (OutOfStockException e)
            {
                Console.WriteLine(e.Message + e.StackTrace);
            }
        }
    }
}
