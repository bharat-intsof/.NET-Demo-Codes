﻿using System;

namespace Day6_Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implement a user define Exception  for an age enterred by user which is less than 20? ");

            Console.WriteLine("Enter Age");
            Age a = new Age();
            try
            {
                a.show();
            }
            catch (AgeIsLessException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
