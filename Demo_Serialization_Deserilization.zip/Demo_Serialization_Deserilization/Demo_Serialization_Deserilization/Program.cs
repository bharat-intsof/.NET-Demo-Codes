﻿using System;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Serialization_Deserilization
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Tutriol obj = new Tutriol();
            obj.ID = 1;
            obj.Name = "ASP.NET MVC";

            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream("C:\\Users\\Bharat Choudhary\\Desktop\\.NET\\Demo_Serialization_Deserilization\\Demo_Serialization_Deserilization\\Demo.txt", FileMode.Create, FileAccess.Write);

            //Serializing the objecte
            formatter.Serialize(stream, obj);
            stream.Close();
            Console.WriteLine("Objects has been serialized...!!!");

            Tutriol objNew = (Tutriol)formatter.Deserialize(stream);
            Console.WriteLine("Data After Deserilization is like...");
            Console.WriteLine(objNew.ID);
            Console.WriteLine(objNew.Name);

        }
    }
}
