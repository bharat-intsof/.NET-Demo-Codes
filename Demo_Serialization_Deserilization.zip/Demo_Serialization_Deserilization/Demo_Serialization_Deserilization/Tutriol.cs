﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Serialization_Deserilization
{
    [Serializable]
    internal class Tutriol
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
