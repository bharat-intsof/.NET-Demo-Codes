﻿using System;

namespace Day6_Multicasting_delegates
{
    public delegate void delmethod(int x, int y);//Delegates declaration 
    class Program
    {
        public void Add(int x , int y)
        {
            Console.WriteLine("You are implemtating Add()");
            Console.WriteLine(x+y);
        }

        public void Subtract(int x , int y)
        {
            Console.WriteLine("You are in Subtract mrthod()");
            Console.WriteLine(x-y);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Program obj1 = new Program();
            delmethod del = new delmethod(obj1.Add);
            //Multicasting delegare like this 
            del += new delmethod(obj1.Subtract);
            del(45, 25);
            Console.WriteLine("After Removing the ref of Add()");
            del -= new delmethod(obj1.Add);
            del(20, 25);
        }
    }
}
