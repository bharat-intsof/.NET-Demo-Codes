﻿using System;

namespace Dy6_Delegate
{
    class Program
    {

        public delegate void delmethod(); //Declaration of delegates
        public static void display()
        {
            Console.WriteLine("Inside Display()");
        }
        public static void show()
        {
            Console.WriteLine("Inside show()");
        }

        public void print()
        {
            Console.WriteLine("Inside print()");
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Single casting Delegates..!!");

            //Asigning static method show() to delegate

            delmethod del1 = Program.show;

            delmethod del2 = new delmethod(Program.display);
            Program obj1 = new Program();

            delmethod del3 = obj1.print;

            del1();
            del2();
            del3();
        }


    }
}
