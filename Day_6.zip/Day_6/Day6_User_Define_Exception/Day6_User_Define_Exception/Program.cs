﻿using System;

namespace Day6_User_Define_Exception
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("User Define Exception");
            temp temperature = new temp();

            try
            {
                temperature.showTemp();
            }
            catch( TempIsZeroException e)
            {
                Console.WriteLine("Temperature is Zero Exception: {0}", e.Message);
            }
        }
    }
}
