﻿using System;

namespace Day5_Operator_Overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Operator Overloading Demo....!!!!");
            Calculator calc1 = new Calculator( 25, -55);
            {
                calc1 = -calc1;

                calc1.Print();
            }
        }
    }
}
