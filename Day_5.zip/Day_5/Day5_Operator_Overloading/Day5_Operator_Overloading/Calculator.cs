﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day5_Operator_Overloading
{
    class Calculator
    {
        public int number1, number2;
        public Calculator(int num1, int num2)
        {
            number1 = num1;
            number2 = num2;
        }
        //Function to perform operator - By changing sign of intergers
        public static Calculator operator -(Calculator c1)
        {
            c1.number1 = -c1.number1;
            c1.number2 = -c1.number2;
            return c1;
        }

        public void Print()
        {
            Console.WriteLine("Number 1 = " + number1);
            Console.WriteLine("Number 2 = " + number2);
        }
    }
}
