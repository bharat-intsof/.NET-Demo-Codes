﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day5_Calc_Overloading_practice
{
    class Calculator
    {
        
    }
}
