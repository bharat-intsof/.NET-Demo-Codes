﻿using System;

namespace Day5_Calc_Overloading_practice
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator num1 = new
        }
    }
}
