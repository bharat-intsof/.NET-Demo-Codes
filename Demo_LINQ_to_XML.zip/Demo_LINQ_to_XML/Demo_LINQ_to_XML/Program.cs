﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Demo_LINQ_to_XML
{
    class Program
    {
        string path = "C:\\Users\\Bharat Choudhary\\Desktop\\.NET\\Demo_LINQ_to_XML\\Demo_LINQ_to_XML\\ParticipantsDeyails.xml";

        private void GETXMLData()
        {

            XDocument doc = XDocument.Load(path);
            var students = from participant in doc.Descendants("Participant")
                           select new
                           {
                               ID = Convert.ToInt32(participant.Attribute("ID").Value),
                               Name = participant.Element("Name").Value
                           };
            foreach (var student in students)
            {
                Console.WriteLine(student.ID + "-" + student.Name);
            }
        }
        private void InsertXMLData(string name)
        {
            try
            {
                XDocument myXML = XDocument.Load(path);
                XElement newparticipant = new XElement("Participant",new XElement("Name", name));
                var LastStudent = myXML.Descendants("Participant").Last();//Get the last element
                int newID = Convert.ToInt32(LastStudent.Attribute("ID").Value);

                newparticipant.SetAttributeValue("ID", newID +1);//Setting Attribute
                myXML.Element("Participants").Add(newparticipant);//Adding new Element
                myXML.Save(path);//Saving changes
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private void Modify_XML_Data(string name, int Id)
        {
            try
            {
                XDocument myXML_2 = XDocument.Load(path);
                XElement items = myXML_2.Descendants("Participant")
                                  .Where(a => a.Attribute("Id").Value.Equals(Id.ToString())).FirstOrDefault();

                items.Element("Name").Value = name;
                myXML_2.Save(path);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private void Delete_XMl_Data(int Id)
        {
            try
            {
                XDocument myXML_3 = XDocument.Load(path);
                XElement Dparticipant = myXML_3.Descendants("Participant").Where(d=> d.Attribute("ID").Value.Equals(Id.ToString())).FirstOrDefault();

                Dparticipant.Remove();
                myXML_3.Save(path);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing LINQ to XML");

            Program obj1 = new Program();
            obj1.GETXMLData();

            //obj1.InsertXMLData("Sasikanth");

            //obj1.Modify_XML_Data("Rohan", 4);
            //obj1.GETXMLData();

            obj1.Delete_XMl_Data(5);
            obj1.GETXMLData();
        }
    }
}
